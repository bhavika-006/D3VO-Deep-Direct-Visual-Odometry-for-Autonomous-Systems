import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvBlock(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, stride=stride, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.net(x)


class DepthUncertaintyNet(nn.Module):
    def __init__(self, min_depth=0.1, max_depth=80.0):
        super().__init__()
        self.min_depth = min_depth
        self.max_depth = max_depth

        self.enc1 = ConvBlock(3, 32, stride=2)
        self.enc2 = ConvBlock(32, 64, stride=2)
        self.enc3 = ConvBlock(64, 128, stride=2)
        self.enc4 = ConvBlock(128, 256, stride=2)

        self.dec3 = ConvBlock(256 + 128, 128)
        self.dec2 = ConvBlock(128 + 64, 64)
        self.dec1 = ConvBlock(64 + 32, 32)

        self.depth_head = nn.Conv2d(32, 1, 3, padding=1)
        self.uncertainty_head = nn.Conv2d(32, 1, 3, padding=1)

    def forward(self, x):
        h, w = x.shape[-2:]

        e1 = self.enc1(x)
        e2 = self.enc2(e1)
        e3 = self.enc3(e2)
        e4 = self.enc4(e3)

        d3 = F.interpolate(e4, size=e3.shape[-2:], mode="bilinear", align_corners=False)
        d3 = self.dec3(torch.cat([d3, e3], dim=1))

        d2 = F.interpolate(d3, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        d2 = self.dec2(torch.cat([d2, e2], dim=1))

        d1 = F.interpolate(d2, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        d1 = self.dec1(torch.cat([d1, e1], dim=1))

        out = F.interpolate(d1, size=(h, w), mode="bilinear", align_corners=False)

        disp = torch.sigmoid(self.depth_head(out))
        depth = self.min_depth + (self.max_depth - self.min_depth) * disp

        uncertainty = F.softplus(self.uncertainty_head(out)) + 1e-4

        return depth, uncertainty
