import argparse
import os
import yaml
import torch
import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader

from models.depth_uncertainty_net import DepthUncertaintyNet
from models.pose_net import PoseNet
from utils.dataset import FramePairDataset


def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--checkpoint", default="checkpoints/best_model.pth")
    args = parser.parse_args()

    cfg = load_config(args.config)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    dataset = FramePairDataset(cfg["data_dir"], cfg["img_height"], cfg["img_width"])
    loader = DataLoader(dataset, batch_size=1, shuffle=False)

    depth_net = DepthUncertaintyNet(cfg["min_depth"], cfg["max_depth"]).to(device)
    pose_net = PoseNet().to(device)

    ckpt = torch.load(args.checkpoint, map_location=device)
    depth_net.load_state_dict(ckpt["depth_net"])
    pose_net.load_state_dict(ckpt["pose_net"])

    depth_net.eval()
    pose_net.eval()

    poses = [[0.0, 0.0]]
    current = np.array([0.0, 0.0])

    with torch.no_grad():
        for img_t, img_t1, _ in loader:
            img_t = img_t.to(device)
            img_t1 = img_t1.to(device)

            pose = pose_net(img_t, img_t1)[0].cpu().numpy()
            tx, tz = pose[3], pose[5]
            current = current + np.array([tx, tz])
            poses.append(current.copy())

    poses = np.array(poses)

    os.makedirs(cfg["output_dir"], exist_ok=True)

    plt.figure()
    plt.plot(poses[:, 0], poses[:, 1], marker="o")
    plt.title("Predicted Camera Trajectory")
    plt.xlabel("X translation")
    plt.ylabel("Z translation")
    plt.grid(True)
    plt.savefig(os.path.join(cfg["output_dir"], "predicted_trajectory.png"))
    plt.close()

    print("Trajectory saved to outputs/predicted_trajectory.png")


if __name__ == "__main__":
    main()
