import argparse
import os
import yaml
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from models.depth_uncertainty_net import DepthUncertaintyNet
from models.pose_net import PoseNet
from utils.dataset import FramePairDataset
from utils.geometry import make_intrinsics, inverse_warp
from losses.photometric import uncertainty_photometric_loss
from losses.smoothness import edge_aware_smoothness_loss
from utils.visualize import save_loss_curve


def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    os.makedirs(cfg["output_dir"], exist_ok=True)
    os.makedirs(cfg["checkpoint_dir"], exist_ok=True)

    dataset = FramePairDataset(cfg["data_dir"], cfg["img_height"], cfg["img_width"])
    loader = DataLoader(
        dataset,
        batch_size=cfg["batch_size"],
        shuffle=True,
        num_workers=cfg["num_workers"],
        drop_last=True
    )

    depth_net = DepthUncertaintyNet(cfg["min_depth"], cfg["max_depth"]).to(device)
    pose_net = PoseNet().to(device)

    optimizer = torch.optim.Adam(
        list(depth_net.parameters()) + list(pose_net.parameters()),
        lr=cfg["learning_rate"]
    )

    all_losses = []
    best_loss = float("inf")

    for epoch in range(cfg["epochs"]):
        depth_net.train()
        pose_net.train()
        epoch_loss = 0.0

        pbar = tqdm(loader, desc=f"Epoch {epoch+1}/{cfg['epochs']}")

        for img_t, img_t1, _ in pbar:
            img_t = img_t.to(device)
            img_t1 = img_t1.to(device)

            B, _, H, W = img_t.shape

            depth, uncertainty = depth_net(img_t)
            pose = pose_net(img_t, img_t1)

            K = make_intrinsics(
                B, H, W,
                fx=cfg["fx"], fy=cfg["fy"],
                cx=cfg["cx"], cy=cfg["cy"],
                device=device
            )

            reconstructed, valid = inverse_warp(img_t1, depth, pose, K)

            photo_loss, _ = uncertainty_photometric_loss(
                img_t, reconstructed, uncertainty, valid
            )

            smooth_loss = edge_aware_smoothness_loss(depth / depth.mean(), img_t)
            loss = photo_loss + cfg["smoothness_weight"] * smooth_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            val = loss.item()
            all_losses.append(val)
            epoch_loss += val
            pbar.set_postfix(loss=val)

        avg_loss = epoch_loss / len(loader)
        print(f"Epoch {epoch+1}: avg loss = {avg_loss:.6f}")

        ckpt = {
            "depth_net": depth_net.state_dict(),
            "pose_net": pose_net.state_dict(),
            "config": cfg
        }

        torch.save(ckpt, os.path.join(cfg["checkpoint_dir"], "last_model.pth"))

        if avg_loss < best_loss:
            best_loss = avg_loss
            torch.save(ckpt, os.path.join(cfg["checkpoint_dir"], "best_model.pth"))

        save_loss_curve(all_losses, os.path.join(cfg["output_dir"], "loss_curve.png"))

    print("Training complete.")
    print("Best model saved to checkpoints/best_model.pth")


if __name__ == "__main__":
    main()
