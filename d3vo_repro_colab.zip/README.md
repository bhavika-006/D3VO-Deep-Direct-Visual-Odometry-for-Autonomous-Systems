# D3VO Reproduction-Style Project for Google Colab

This project reproduces the deep-learning core of D3VO:

- monocular depth prediction
- relative pose prediction
- uncertainty-aware photometric reconstruction
- edge-aware depth smoothness
- depth, uncertainty, reconstruction, error-map, and trajectory outputs

It does **not** reproduce the full original D3VO direct sparse odometry backend. It reproduces the ML part suitable for a lab/project presentation.

## Colab setup

```bash
!unzip d3vo_repro_colab.zip
%cd d3vo_repro_colab
!pip install -r requirements.txt
```

## Dataset format

Put consecutive frames here:

```text
data/kitti_sequence/image_2/
    000000.png
    000001.png
    000002.png
```

You can use KITTI odometry frames or any monocular RGB image sequence.

## Train

```bash
!python train.py --config config.yaml
```

## Inference

```bash
!python infer.py --config config.yaml --checkpoint checkpoints/best_model.pth
```

## Trajectory plot

```bash
!python evaluate.py --config config.yaml --checkpoint checkpoints/best_model.pth
```

## PPT claim

> I reproduced the deep learning component of D3VO by implementing monocular depth prediction, pose prediction, uncertainty-aware photometric loss, self-supervised reconstruction, and visual odometry-style trajectory estimation.
