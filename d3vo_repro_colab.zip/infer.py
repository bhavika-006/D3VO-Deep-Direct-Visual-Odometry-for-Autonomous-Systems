import argparse
import os
import yaml
import torch
from torch.utils.data import DataLoader

from models.depth_uncertainty_net import DepthUncertaintyNet
from models.pose_net import PoseNet
from utils.dataset import FramePairDataset
from utils.geometry import make_intrinsics, inverse_warp
from losses.photometric import uncertainty_photometric_loss
from utils.visualize import save_depth, save_uncertainty, save_rgb, save_error


def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--checkpoint", default="checkpoints/best_model.pth")
    parser.add_argument("--num_samples", type=int, default=8)
    args = parser.parse_args()

    cfg = load_config(args.config)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    os.makedirs(cfg["output_dir"], exist_ok=True)

    dataset = FramePairDataset(cfg["data_dir"], cfg["img_height"], cfg["img_width"])
    loader = DataLoader(dataset, batch_size=1, shuffle=False)

    depth_net = DepthUncertaintyNet(cfg["min_depth"], cfg["max_depth"]).to(device)
    pose_net = PoseNet().to(device)

    ckpt = torch.load(args.checkpoint, map_location=device)
    depth_net.load_state_dict(ckpt["depth_net"])
    pose_net.load_state_dict(ckpt["pose_net"])

    depth_net.eval()
    pose_net.eval()

    with torch.no_grad():
        for idx, (img_t, img_t1, _) in enumerate(loader):
            if idx >= args.num_samples:
                break

            img_t = img_t.to(device)
            img_t1 = img_t1.to(device)

            B, _, H, W = img_t.shape

            depth, uncertainty = depth_net(img_t)
            pose = pose_net(img_t, img_t1)

            K = make_intrinsics(
                B, H, W,
                fx=cfg["fx"], fy=cfg["fy"],
                cx=cfg["cx"], cy=cfg["cy"],
                device=device
            )

            reconstructed, valid = inverse_warp(img_t1, depth, pose, K)
            _, error = uncertainty_photometric_loss(img_t, reconstructed, uncertainty, valid)

            save_rgb(img_t[0], os.path.join(cfg["output_dir"], f"{idx:03d}_input.png"))
            save_rgb(reconstructed[0], os.path.join(cfg["output_dir"], f"{idx:03d}_reconstructed.png"))
            save_depth(depth[0], os.path.join(cfg["output_dir"], f"{idx:03d}_depth.png"))
            save_uncertainty(uncertainty[0], os.path.join(cfg["output_dir"], f"{idx:03d}_uncertainty.png"))
            save_error(error[0], os.path.join(cfg["output_dir"], f"{idx:03d}_photometric_error.png"))

    print("Inference complete. Check outputs folder.")


if __name__ == "__main__":
    main()
