import numpy as np
import matplotlib.pyplot as plt


def tensor_to_np_img(x):
    x = x.detach().cpu().permute(1, 2, 0).numpy()
    return np.clip(x, 0, 1)


def save_depth(depth, path):
    depth = depth.detach().cpu().squeeze().numpy()
    depth = (depth - depth.min()) / (depth.max() - depth.min() + 1e-8)
    plt.imsave(path, depth, cmap="inferno")


def save_uncertainty(uncertainty, path):
    u = uncertainty.detach().cpu().squeeze().numpy()
    u = (u - u.min()) / (u.max() - u.min() + 1e-8)
    plt.imsave(path, u, cmap="magma")


def save_error(error, path):
    e = error.detach().cpu().squeeze().numpy()
    e = (e - e.min()) / (e.max() - e.min() + 1e-8)
    plt.imsave(path, e, cmap="hot")


def save_rgb(tensor_img, path):
    img = tensor_to_np_img(tensor_img)
    plt.imsave(path, img)


def save_loss_curve(losses, path):
    plt.figure()
    plt.plot(losses)
    plt.title("Training Loss")
    plt.xlabel("Iteration")
    plt.ylabel("Loss")
    plt.grid(True)
    plt.savefig(path)
    plt.close()
