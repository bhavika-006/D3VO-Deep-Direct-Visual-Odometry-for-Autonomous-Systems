import torch


def gradient_x(img):
    return img[:, :, :, :-1] - img[:, :, :, 1:]


def gradient_y(img):
    return img[:, :, :-1, :] - img[:, :, 1:, :]


def edge_aware_smoothness_loss(depth, image):
    depth_dx = gradient_x(depth)
    depth_dy = gradient_y(depth)

    image_dx = torch.mean(torch.abs(gradient_x(image)), dim=1, keepdim=True)
    image_dy = torch.mean(torch.abs(gradient_y(image)), dim=1, keepdim=True)

    weight_x = torch.exp(-image_dx)
    weight_y = torch.exp(-image_dy)

    return (torch.abs(depth_dx) * weight_x).mean() + (torch.abs(depth_dy) * weight_y).mean()
