import os
from PIL import Image
from torch.utils.data import Dataset
import torchvision.transforms as T


class FramePairDataset(Dataset):
    def __init__(self, image_dir, height=128, width=416):
        self.image_dir = image_dir
        self.paths = sorted([
            os.path.join(image_dir, f)
            for f in os.listdir(image_dir)
            if f.lower().endswith((".png", ".jpg", ".jpeg"))
        ])

        if len(self.paths) < 2:
            raise RuntimeError(
                f"Need at least 2 images in {image_dir}. "
                "Add KITTI-style consecutive frames first."
            )

        self.transform = T.Compose([
            T.Resize((height, width)),
            T.ToTensor()
        ])

    def __len__(self):
        return len(self.paths) - 1

    def __getitem__(self, idx):
        img_t = Image.open(self.paths[idx]).convert("RGB")
        img_t1 = Image.open(self.paths[idx + 1]).convert("RGB")
        return self.transform(img_t), self.transform(img_t1), self.paths[idx]
