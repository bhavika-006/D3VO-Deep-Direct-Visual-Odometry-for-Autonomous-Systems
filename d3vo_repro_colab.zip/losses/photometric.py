import torch


def uncertainty_photometric_loss(target, reconstructed, uncertainty, valid_mask):
    residual = torch.mean(torch.abs(target - reconstructed), dim=1, keepdim=True)
    loss = residual / uncertainty + torch.log(uncertainty)
    loss = loss * valid_mask
    return loss.sum() / (valid_mask.sum() + 1e-8), residual


def plain_photometric_loss(target, reconstructed, valid_mask):
    residual = torch.mean(torch.abs(target - reconstructed), dim=1, keepdim=True)
    loss = residual * valid_mask
    return loss.sum() / (valid_mask.sum() + 1e-8)
