import torch
import torch.nn as nn


class PoseNet(nn.Module):
    def __init__(self):
        super().__init__()

        self.encoder = nn.Sequential(
            nn.Conv2d(6, 32, 7, stride=2, padding=3),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 64, 5, stride=2, padding=2),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 128, 3, stride=2, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 256, 3, stride=2, padding=1),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1)
        )

        self.fc = nn.Linear(256, 6)

    def forward(self, img_t, img_t1):
        x = torch.cat([img_t, img_t1], dim=1)
        x = self.encoder(x).flatten(1)
        pose = self.fc(x)
        return 0.01 * pose
