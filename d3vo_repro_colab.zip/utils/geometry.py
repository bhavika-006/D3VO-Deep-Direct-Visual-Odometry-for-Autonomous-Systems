import torch
import torch.nn.functional as F


def make_intrinsics(batch_size, height, width, fx=0.58, fy=1.92, cx=0.50, cy=0.50, device="cpu"):
    K = torch.eye(3, device=device).unsqueeze(0).repeat(batch_size, 1, 1)
    K[:, 0, 0] = fx * width
    K[:, 1, 1] = fy * height
    K[:, 0, 2] = cx * width
    K[:, 1, 2] = cy * height
    return K


def axis_angle_to_matrix(vec):
    B = vec.shape[0]
    angle = torch.norm(vec, dim=1, keepdim=True).clamp(min=1e-8)
    axis = vec / angle

    x, y, z = axis[:, 0], axis[:, 1], axis[:, 2]
    zeros = torch.zeros_like(x)

    K = torch.stack([
        zeros, -z, y,
        z, zeros, -x,
        -y, x, zeros
    ], dim=1).view(B, 3, 3)

    I = torch.eye(3, device=vec.device).unsqueeze(0).repeat(B, 1, 1)
    angle = angle.view(B, 1, 1)

    R = I + torch.sin(angle) * K + (1 - torch.cos(angle)) * torch.bmm(K, K)
    return R


def pose_vec_to_matrix(pose):
    B = pose.shape[0]
    R = axis_angle_to_matrix(pose[:, :3])
    t = pose[:, 3:].view(B, 3, 1)

    T = torch.eye(4, device=pose.device).unsqueeze(0).repeat(B, 1, 1)
    T[:, :3, :3] = R
    T[:, :3, 3:4] = t
    return T


def meshgrid(batch_size, height, width, device):
    y, x = torch.meshgrid(
        torch.arange(height, device=device),
        torch.arange(width, device=device),
        indexing="ij"
    )
    ones = torch.ones_like(x)
    grid = torch.stack([x, y, ones], dim=0).float()
    grid = grid.unsqueeze(0).repeat(batch_size, 1, 1, 1)
    return grid.view(batch_size, 3, -1)


def inverse_warp(source_img, depth, pose, K):
    B, _, H, W = source_img.shape
    device = source_img.device

    pix_coords = meshgrid(B, H, W, device)
    K_inv = torch.inverse(K)

    cam_points = torch.bmm(K_inv, pix_coords) * depth.view(B, 1, -1)

    T = pose_vec_to_matrix(pose)
    R = T[:, :3, :3]
    t = T[:, :3, 3:4]

    cam_points_src = torch.bmm(R, cam_points) + t

    proj = torch.bmm(K, cam_points_src)
    x = proj[:, 0] / proj[:, 2].clamp(min=1e-6)
    y = proj[:, 1] / proj[:, 2].clamp(min=1e-6)

    x_norm = 2 * (x / (W - 1)) - 1
    y_norm = 2 * (y / (H - 1)) - 1

    grid = torch.stack([x_norm, y_norm], dim=2).view(B, H, W, 2)

    warped = F.grid_sample(
        source_img,
        grid,
        mode="bilinear",
        padding_mode="border",
        align_corners=True
    )

    valid = (
        (x_norm > -1) & (x_norm < 1) &
        (y_norm > -1) & (y_norm < 1)
    ).float().view(B, 1, H, W)

    return warped, valid
